

## <entry>
## Defunct in 0.3.1
classWF <- function(form,train,test,learner,eval,...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>

## <entry>
## Defunct in 0.3.1
regrWF <- function(form,train,test,learner,eval,simpl,...) 
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>


## <entry>
## Defunct in 0.3.1
slideRegrWF <- function(...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>


## <entry>
## Defunct in 0.3.1
growRegrWF <- function(...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>


## <entry>
## Defunct in 0.3.1
tsRegrWF <- function(form,train,test,type,learner,eval,simpl,relearn.step,verbose,...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>



## <entry>
## Defunct in 0.3.1
slideClassWF <- function(...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>



## <entry>
## Defunct in 0.3.1
growClassWF <- function(...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>



## <entry>
## Defunct in 0.3.1
tsClassWF <- function(form,train,test,type,learner,eval,relearn.step,verbose,...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>


## <entry>
## Defunct in 0.4.0
timeseriesWF <- function(form,train,test,type,learner,eval,relearn.step,verbose,...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>

## <entry>
## Defunct in 0.4.0
standardWF <- function(form,train,test,type,learner,eval,relearn.step,verbose,...)
  .Defunct("- no replacement function provided -",package="DMwR",msg="Work flow based functions introduced in branch 0.3.x where removed from 0.4.0 as they introduced incompatibilities with the code in the book associated with this package. They will be available on a forecoming new package on experimental comparisons of predictive models.")
## </entry>
